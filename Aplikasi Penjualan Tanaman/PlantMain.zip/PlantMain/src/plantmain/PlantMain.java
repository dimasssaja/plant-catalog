/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package plantmain;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class PlantMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Plant p = new Plant();
        Anggrek q = new Anggrek();
        Garden mG=new Garden("Kebun Bunga");
        Scanner sc= new Scanner(System.in);
        //String pilih;
        //Scanner pilihbunga = new Scanner(System.in);
        //pilih= pilihbunga.next();
        Scanner sc1 = new Scanner(System.in);
        int inp = 0;
        do {
            System.out.println("Pilih Aksi\nMasukkan 0 untuk memberi air\n1 untuk memberi pupuk\nMasukkan 2 Jika Tidak Ingin Memberi Pupuk dan air\nMasukkan 3 jika ingin menanam\nMasukkan 4 jika ingin memanen \n999 untuk keluar");
            inp = sc.nextInt();
            switch(inp){
                case 0: mG.beriAir();
                mG.displayPlant();
                break;
                case 1: mG.beriPupuk();
                mG.displayPlant();
                break;
                case 2: mG.membiarkantanaman();
                mG.displayPlant();
                break;
                case 3: Plant p =new Plant();
                        if(mG.addPlant(p)){
                            printMessage("Tanaman Berhasil Ditambahkan");
                        }else{
                            printMessage("Kebun Sudah Penuh");
                        }
                break;
                case 4: int n= mG.harvestPlant();
                        if(n>0){
                            printMessage("Tanaman Telah Berhasil Dipanen!!");
                        }else{
                            printMessage("Maaf, Tidak ada tumbuhan yang bisa dipanen sekarang :(");
                        }
            }
            mG.displayPlant();
        }while (inp!=999);
    }
    public static void printMessage(String str){
        System.out.println("***************************");
        System.out.println("**"+str);
        System.out.println("***************************");
    }
}
